from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DesktopSettings:
    download_directory: str = field(default_factory=lambda: str(Path.home() / "Downloads"))
    notifications_enabled: bool = False
    clipboard_enabled: bool = False
    paired_devices: set[str] = field(default_factory=set)
